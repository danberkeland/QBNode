/* Just testing VS Code */

const OAuthClient = require("intuit-oauth");
var QuickBooks = require("node-quickbooks");

let access = {
  refreshToken: "AB116435532616nT8imZ7uF82al9LK11q0DkR1jAvsOxQn5m9D",
  accessToken:
    "eyJlbmMiOiJBMTI4Q0JDLUhTMjU2IiwiYWxnIjoiZGlyIn0..LWiFJTJH7t33ERqv1FHJiw.pd1EHfITmerAfXwMvuLjQcbwNH1rZYeECfmv6s1SoZ_nlgBUpUDIFmuqo4oiXco34-CfxTXjLTi5f-pFmgB88T36BZudzIHP32qzE8RSzvCWYWkmV6YAO6SXC_qzWX9BZMa0-cpgCq8kvBU1VgAYP9gjxJzDUYZWbRTEOoneTCbmPqlRmC_WcMvPV7UkynnNcHBbDigRvmm1pj6d4417wvgU_fj_CIUiBO6oQ8qTk0-OXyUnd9uZZPlWlsYzRU912wbOw7x9kcWb2DoWOJL58A-9p299ysgFkcrP-YYGTwbrxEj9_1jzeaBSuGDlOym-eJgymoyV9VZdY7_qxeCRisns-Ol2Tg97RKxXXhvd15ufsU86CnrGUR5s7vJtg1kNQk6QcOKoM4KvUJHrW0dRr_4v0Pn4n1DJwqJefU4lFVEJVVlaABtOQZD4fTm9im87N4QrvvAPm7gdqUhvqWQ3R3qB6n7kpjKETg0Vkvg184lDNPr34mXJdvVVw1lLJMGpfsqp5tCgRgxc5l1EFBI0Xclnpu4GR34CZw3LKlbD9mjHIMxVYN7CsX5k8QiBo7T_qCMJ5h_KE8OI6XId6qS96JXEuKJjBntdzvbemkSQL3KL0_7fus4iRan6zQ09MOEwpIAby2ff2VzYXJmHaDJtRqXLhNepglxh9mFeMwbA0JPj_oxqz8hrQ8hahqgppg-QcaQP8aUwkpMSzLgXvDEB1BLONo_7eSfM3OLNAjsMGtM.EKuI00TRCxsPuBVIji7WNg",

  expires_in: 3600,
  x_refresh_token_expires_in: 8726400,
};

const oauthClient = new OAuthClient({
  clientId: "ABMoSkUwyZik7OSSRVyzobfowXSFXmZSwubuebPtgJjDIDKOjB",
  clientSecret: "kIc5Fh5wIO0D5GZ6dJUWFaIcegw0UCqGXk5LIPpJ",
  environment: "production",
  redirectUri: "https://www.bpbadmin.com/Billing",
});

qbo = new QuickBooks(
  "ABMoSkUwyZik7OSSRVyzobfowXSFXmZSwubuebPtgJjDIDKOjB",
  "kIc5Fh5wIO0D5GZ6dJUWFaIcegw0UCqGXk5LIPpJ",
  "eyJlbmMiOiJBMTI4Q0JDLUhTMjU2IiwiYWxnIjoiZGlyIn0..LWiFJTJH7t33ERqv1FHJiw.pd1EHfITmerAfXwMvuLjQcbwNH1rZYeECfmv6s1SoZ_nlgBUpUDIFmuqo4oiXco34-CfxTXjLTi5f-pFmgB88T36BZudzIHP32qzE8RSzvCWYWkmV6YAO6SXC_qzWX9BZMa0-cpgCq8kvBU1VgAYP9gjxJzDUYZWbRTEOoneTCbmPqlRmC_WcMvPV7UkynnNcHBbDigRvmm1pj6d4417wvgU_fj_CIUiBO6oQ8qTk0-OXyUnd9uZZPlWlsYzRU912wbOw7x9kcWb2DoWOJL58A-9p299ysgFkcrP-YYGTwbrxEj9_1jzeaBSuGDlOym-eJgymoyV9VZdY7_qxeCRisns-Ol2Tg97RKxXXhvd15ufsU86CnrGUR5s7vJtg1kNQk6QcOKoM4KvUJHrW0dRr_4v0Pn4n1DJwqJefU4lFVEJVVlaABtOQZD4fTm9im87N4QrvvAPm7gdqUhvqWQ3R3qB6n7kpjKETg0Vkvg184lDNPr34mXJdvVVw1lLJMGpfsqp5tCgRgxc5l1EFBI0Xclnpu4GR34CZw3LKlbD9mjHIMxVYN7CsX5k8QiBo7T_qCMJ5h_KE8OI6XId6qS96JXEuKJjBntdzvbemkSQL3KL0_7fus4iRan6zQ09MOEwpIAby2ff2VzYXJmHaDJtRqXLhNepglxh9mFeMwbA0JPj_oxqz8hrQ8hahqgppg-QcaQP8aUwkpMSzLgXvDEB1BLONo_7eSfM3OLNAjsMGtM.EKuI00TRCxsPuBVIji7WNg",
  false, // no token secret for oAuth 2.0
  "480063645",
  false, // use the sandbox?
  true, // enable debugging?
  null, // set minorversion, or null for the latest version
  "2.0", //oAuth version
  "AB116435532616nT8imZ7uF82al9LK11q0DkR1jAvsOxQn5m9D"
);
let response;
let DisplayName = "Novo";


const findCust = async () => {
  qbo.findCustomers({ DisplayName: DisplayName }, (err, CompanyInfo) => {
    if (err) {
      console.log("We've got an error!", err);
    } else {
      return CompanyInfo;
    }
  });
}



exports.handler = async (event, context) => {

  oauthClient.setToken(access);

  if (oauthClient.isAccessTokenValid()) {
    console.log("The access_token is valid");
  } else {
    console.log("Token is not valid");
  }

  let response = await findCust()
  return response

  

  
};





